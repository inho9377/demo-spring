package com.example.booklibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BooklibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
